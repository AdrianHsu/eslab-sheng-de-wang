GStreamer C API Project
=======================
* GStreamer Command Introduction
 * Hello GStreamer
 * V4L2 Input Command
 * Streaming
* GStreamer C API
 * Hello GStreamer In C API
 * Bus (Event Handler)

For more information, please refer to [GStreamer documentation](https://gstreamer.freedesktop.org/documentation/)